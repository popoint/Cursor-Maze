CURSOR MAZE

Copyright (C) 2020 KygekDev.
Developed by KygekDev since August 26th, 2020.

Cursor Maze is a game made using PowerPoint. Cursor Maze may contain many bugs as it is currently on Beta. Please report the developer if you found bug(s). Support the developer by contributing in GitHub. If you want to be a collaborator, please contact the developer via Discord (KygekDev#6415). Any contributions will be very appreciated!

CREDITS

Musics are from AShamaluevMusic and YouTube Audio Library.
This project is inspired by Cursor Adventure and other games.
Thanks to the community for helping us to share Cursor Maze to the general public.

=================================================

This project is under GPL-3.0 open source license. See LICENSE.txt for more information.